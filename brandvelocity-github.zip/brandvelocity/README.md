# BrandVelocity

> **We Build Brands That Matter**

A stunning space-themed marketing and branding agency website built with React, TypeScript, and modern web technologies. Features an interactive AI-powered quote calculator (Velocity AI), SEO-optimized blog content, and a beautiful cosmic design.

![BrandVelocity](https://img.shields.io/badge/Built%20with-React-61DAFB?style=for-the-badge&logo=react&logoColor=white)
![TypeScript](https://img.shields.io/badge/TypeScript-3178C6?style=for-the-badge&logo=typescript&logoColor=white)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-38B2AC?style=for-the-badge&logo=tailwind-css&logoColor=white)

## ✨ Features

- **🚀 Velocity AI** - Interactive quote calculator with gamified questions and PDF report generation
- **🎨 Space-Themed Design** - Stunning cosmic animations with morphing gradient blobs
- **📱 Fully Responsive** - Mobile-first design with hamburger menu navigation
- **📝 SEO Optimized** - 10 blog posts targeting Devon & Cornwall markets
- **💾 Database Integration** - Stores contact submissions and quote requests
- **🔐 User Authentication** - Built-in OAuth support
- **📊 Portfolio Showcase** - Display your work with project cards
- **🎯 Page Transitions** - Smooth black & white diagonal wipe effects

## 🛠️ Tech Stack

### Frontend
- **React 19** - Modern UI library
- **TypeScript** - Type-safe development
- **Tailwind CSS 4** - Utility-first styling
- **Wouter** - Lightweight routing
- **shadcn/ui** - Beautiful component library
- **jsPDF** - PDF generation for quotes

### Backend
- **Node.js** - Runtime environment
- **tRPC** - End-to-end typesafe APIs
- **Drizzle ORM** - TypeScript ORM
- **PostgreSQL** - Database (via Drizzle)

## 📦 Installation

### Prerequisites
- Node.js 22.x or higher
- pnpm (recommended) or npm

### Setup

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/brandvelocity.git
cd brandvelocity
```

2. **Install dependencies**
```bash
pnpm install
```

3. **Set up environment variables**
Create a `.env` file in the root directory:
```env
# Database
DATABASE_URL=your_database_url

# JWT Secret
JWT_SECRET=your_jwt_secret_key

# OAuth (optional)
OAUTH_SERVER_URL=your_oauth_server_url

# App Configuration
VITE_APP_TITLE=BrandVelocity
VITE_APP_LOGO=/logo.png
```

4. **Initialize the database**
```bash
pnpm db:push
```

5. **Start the development server**
```bash
pnpm dev
```

The application will be available at `http://localhost:3000`

## 🚀 Deployment

### Build for Production
```bash
pnpm build
```

### Preview Production Build
```bash
pnpm preview
```

## 📁 Project Structure

```
brandvelocity/
├── client/                 # Frontend application
│   ├── public/            # Static assets
│   ├── src/
│   │   ├── components/    # React components
│   │   ├── pages/         # Page components
│   │   ├── contexts/      # React contexts
│   │   ├── hooks/         # Custom hooks
│   │   └── lib/           # Utilities
├── server/                # Backend application
│   ├── routers.ts         # tRPC routers
│   └── db.ts              # Database helpers
├── drizzle/               # Database schema
│   └── schema.ts          # Drizzle schema definitions
└── shared/                # Shared types and constants
```

## 🎯 Key Pages

- **Home** (`/`) - Hero section with Velocity AI CTA
- **About** (`/about`) - Team and mission statement
- **Services** (`/services`) - Four core services showcase
- **Work** (`/work`) - Portfolio with project case studies
- **Blog** (`/blog`) - SEO-optimized articles
- **Contact** (`/contact`) - Contact form with database storage

## 🤖 Velocity AI

The Velocity AI quote calculator asks 5 gamified questions to generate personalized website quotes:

- **Starter Package**: £250-£450 (3-17 days)
- **Professional Package**: £450-£890 (2-3 weeks)
- **Enterprise Package**: £890+ (4-7 weeks)

Features:
- Email collection for lead generation
- PDF report with market comparison
- Shows 30-40% savings vs competitors
- Stores quotes in database

## 📊 SEO Strategy

10 blog posts targeting:
- Devon marketing keywords
- Cornwall business keywords
- Plymouth branding searches
- Local service areas

All posts include:
- 2000+ words of content
- Strategic keyword placement
- Internal linking
- Schema markup

## 🎨 Customization

### Colors
Brand colors are defined in `client/src/index.css`:
- Primary Green: `#1abc9c`
- Dark Green: `#16a085`
- Purple: `#a855f7`
- Pink: `#ec4899`

### Content
Update your business details in:
- `client/src/pages/Contact.tsx` - Contact information
- `client/src/components/Footer.tsx` - Footer details
- `client/src/data/blogPosts.ts` - Blog content

## 📝 License

This project is licensed under the MIT License.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📧 Contact

**BrandVelocity**
- 📍 Plymouth, Devon, UK
- 📞 07426 877552
- 📧 connect@brandvelocity.co.uk
- 🌐 [brandvelocity.co.uk](https://brandvelocity.co.uk)

---

Built with 💚 by BrandVelocity | Accelerating brands into the future with innovative marketing strategies and cosmic creativity.

