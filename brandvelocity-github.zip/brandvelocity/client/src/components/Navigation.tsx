import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Home, Info, Briefcase, FolderOpen, Mail } from "lucide-react";

export default function Navigation() {
  const [location] = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { href: "/", label: "Home", icon: Home },
    { href: "/about", label: "About", icon: Info },
    { href: "/services", label: "Services", icon: Briefcase },
    { href: "/work", label: "Work", icon: FolderOpen },
    { href: "/contact", label: "Contact", icon: Mail },
  ];

  return (
    <>
      {/* Desktop Navigation */}
      <nav
        className={`hidden md:block fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-black/80 backdrop-blur-md border-b border-purple-500/20"
            : "bg-transparent"
        }`}
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link href="/">
              <div className="flex items-center cursor-pointer group">
                <span className="text-2xl font-bold transition-opacity group-hover:opacity-80">
                  <span className="text-[#1abc9c]">Brand</span>
                  <span className="text-white">Velocity</span>
                </span>
              </div>
            </Link>

            {/* Desktop Navigation Links */}
            <div className="flex items-center space-x-8">
              {navLinks.map((link) => (
                <Link key={link.href} href={link.href}>
                  <span
                    className={`relative cursor-pointer text-sm font-medium transition-colors hover:text-purple-400 ${
                      location === link.href
                        ? "text-purple-400"
                        : "text-gray-300"
                    }`}
                  >
                    {link.label}
                    {location === link.href && (
                      <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-pink-500"></span>
                    )}
                  </span>
                </Link>
              ))}
              <Link href="/contact">
                <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Top Bar with Logo */}
      <nav className="md:hidden fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-md border-b border-purple-500/20">
        <div className="flex items-center justify-center h-16 px-4">
          <Link href="/">
            <div className="flex items-center cursor-pointer">
              <span className="text-xl font-bold">
                <span className="text-[#1abc9c]">Brand</span>
                <span className="text-white">Velocity</span>
              </span>
            </div>
          </Link>
        </div>
      </nav>

      {/* Mobile Bottom Navigation (App Style) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-lg border-t border-purple-500/20 pb-safe">
        <div className="grid grid-cols-5 h-16">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = location === link.href;
            
            return (
              <Link key={link.href} href={link.href}>
                <div
                  className={`flex flex-col items-center justify-center h-full cursor-pointer transition-all ${
                    isActive
                      ? "text-[#1abc9c]"
                      : "text-gray-400 hover:text-gray-200"
                  }`}
                >
                  <Icon 
                    size={20} 
                    className={`mb-1 transition-transform ${
                      isActive ? "scale-110" : ""
                    }`}
                  />
                  <span className={`text-xs font-medium ${
                    isActive ? "font-semibold" : ""
                  }`}>
                    {link.label}
                  </span>
                  {isActive && (
                    <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-[#1abc9c] to-[#16a085]"></div>
                  )}
                </div>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Mobile Spacer for Bottom Nav */}
      <div className="md:hidden h-16"></div>
    </>
  );
}

