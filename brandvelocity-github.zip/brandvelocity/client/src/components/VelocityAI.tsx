import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { X, Sparkles, Rocket, Zap, Download, TrendingDown, CheckCircle2 } from "lucide-react";
import { jsPDF } from "jspdf";
import { toast } from "sonner";

interface QuoteResult {
  tier: string;
  exactPrice: number;
  timeline: string;
  features: string[];
  marketPrice: number;
  savings: number;
  savingsPercent: number;
  score: number;
}

export default function VelocityAI() {
  const [isOpen, setIsOpen] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [result, setResult] = useState<QuoteResult | null>(null);
  const [showEmailForm, setShowEmailForm] = useState(false);
  const [email, setEmail] = useState("");
  const [userName, setUserName] = useState("");
  
  // Draggable state
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });



  // Set initial position on mount
  useEffect(() => {
    const isMobile = window.innerWidth < 768;
    if (isMobile) {
      setPosition({ 
        x: window.innerWidth - 180,
        y: window.innerHeight - 100
      });
    } else {
      setPosition({ 
        x: window.innerWidth - 250,
        y: window.innerHeight - 100
      });
    }
  }, []);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({
      x: e.clientX - position.x,
      y: e.clientY - position.y
    });
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setIsDragging(true);
    const touch = e.touches[0];
    setDragStart({
      x: touch.clientX - position.x,
      y: touch.clientY - position.y
    });
  };

  useEffect(() => {
    const handleMove = (clientX: number, clientY: number) => {
      if (isDragging) {
        const newX = clientX - dragStart.x;
        const newY = clientY - dragStart.y;
        
        const maxX = window.innerWidth - 200;
        const maxY = window.innerHeight - 80;
        
        setPosition({
          x: Math.max(0, Math.min(newX, maxX)),
          y: Math.max(0, Math.min(newY, maxY))
        });
      }
    };

    const handleMouseMove = (e: MouseEvent) => handleMove(e.clientX, e.clientY);
    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        handleMove(e.touches[0].clientX, e.touches[0].clientY);
      }
    };

    const handleEnd = () => setIsDragging(false);

    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleEnd);
      document.addEventListener('touchmove', handleTouchMove);
      document.addEventListener('touchend', handleEnd);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleEnd);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleEnd);
    };
  }, [isDragging, dragStart]);

  const questions = [
    {
      question: "What type of website do you need?",
      options: [
        { label: "🏠 Simple Landing Page", value: 1 },
        { label: "💼 Business Website", value: 2 },
        { label: "🛍️ E-commerce Store", value: 3 },
        { label: "🎨 Portfolio/Creative", value: 2 },
      ]
    },
    {
      question: "How many pages do you need?",
      options: [
        { label: "📄 1-3 pages", value: 1 },
        { label: "📚 4-7 pages", value: 2 },
        { label: "📖 8-15 pages", value: 3 },
        { label: "📚 15+ pages", value: 4 },
      ]
    },
    {
      question: "What features do you need?",
      options: [
        { label: "✨ Basic (Contact form)", value: 1 },
        { label: "⚡ Standard (Forms + Blog)", value: 2 },
        { label: "🚀 Advanced (CMS + Database)", value: 3 },
        { label: "💎 Premium (Everything + Custom)", value: 4 },
      ]
    },
    {
      question: "Design complexity?",
      options: [
        { label: "🎯 Template-based", value: 1 },
        { label: "🎨 Custom Design", value: 2 },
        { label: "✨ Premium Custom", value: 3 },
        { label: "🌟 Luxury Bespoke", value: 4 },
      ]
    },
    {
      question: "Content creation needed?",
      options: [
        { label: "📝 I have all content", value: 0 },
        { label: "✍️ Some copywriting help", value: 1 },
        { label: "📸 Content + Images", value: 2 },
        { label: "🎬 Full content creation", value: 3 },
      ]
    }
  ];

  const calculateQuote = (totalScore: number): QuoteResult => {
    let tier = "";
    let basePrice = 0;
    let timeline = "";
    let features: string[] = [];
    let marketMultiplier = 1.4; // Market charges 40% more

    // Calculate exact price based on score (10% less than original ranges)
    if (totalScore <= 6) {
      tier = "Starter Package";
      basePrice = 315; // Was £350, now 10% less
      timeline = "5-10 days";
      marketMultiplier = 1.45; // Market charges 45% more for basic sites
      features = [
        "Professional landing page design",
        "Mobile-responsive layout",
        "Contact form integration",
        "Basic SEO optimization",
        "Fast loading speed",
        "1 month free support"
      ];
    } else if (totalScore <= 10) {
      tier = "Professional Package";
      basePrice = 495; // Was £550, now 10% less
      timeline = "2-3 weeks";
      marketMultiplier = 1.42;
      features = [
        "Multi-page custom website",
        "Advanced responsive design",
        "Content management system",
        "Blog functionality",
        "Advanced SEO setup",
        "Contact forms & integrations",
        "Social media integration",
        "2 months free support",
        "Performance optimization"
      ];
    } else {
      tier = "Enterprise Package";
      basePrice = 765; // Was £850, now 10% less
      timeline = "4-6 weeks";
      marketMultiplier = 1.38;
      features = [
        "Fully custom website design",
        "Advanced CMS & database",
        "E-commerce capabilities",
        "Custom features & integrations",
        "Premium SEO & analytics",
        "Content creation assistance",
        "Brand identity integration",
        "Priority support (3 months)",
        "Performance & security optimization",
        "Training & documentation"
      ];
    }

    // Add score-based price adjustments (smaller increments for exact pricing)
    const scoreAdjustment = (totalScore - 5) * 15; // £15 per point above baseline
    const exactPrice = Math.round(basePrice + scoreAdjustment);
    
    const marketPrice = Math.round(exactPrice * marketMultiplier);
    const savings = marketPrice - exactPrice;
    const savingsPercent = Math.round(((savings) / marketPrice) * 100);

    return {
      tier,
      exactPrice,
      timeline,
      features,
      marketPrice,
      savings,
      savingsPercent,
      score: totalScore
    };
  };

  const handleAnswer = (value: number) => {
    const newAnswers = [...answers, value];
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      const totalScore = newAnswers.reduce((a, b) => a + b, 0);
      const quote = calculateQuote(totalScore);
      setResult(quote);
    }
  };

  const handleBack = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      setAnswers(answers.slice(0, -1));
    }
  };

  const handleReset = () => {
    setCurrentQuestion(0);
    setAnswers([]);
    setResult(null);
    setShowEmailForm(false);
    setEmail("");
    setUserName("");
  };

  const generatePDF = async () => {
    if (!result) return;

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    
    // Black background
    doc.setFillColor(0, 0, 0);
    doc.rect(0, 0, pageWidth, 297, 'F');

    // Green header bar
    doc.setFillColor(26, 188, 156);
    doc.rect(0, 0, pageWidth, 25, 'F');
    
    // Contact info in header
    doc.setFontSize(9);
    doc.setTextColor(255, 255, 255);
    doc.text("📧 connect@brandvelocity.co.uk", 15, 10);
    doc.text("📞 07426 877552", 15, 16);
    doc.text("📍 Plymouth, Devon, UK", 15, 22);

    // Main heading
    doc.setFontSize(28);
    doc.setFont("helvetica", "bold");
    const gradient1 = "We Build";
    const gradient2 = "Brands That Matter";
    doc.setTextColor(255, 255, 255);
    doc.text(gradient1, pageWidth / 2, 45, { align: "center" });
    doc.setTextColor(236, 72, 153); // Pink
    doc.text(gradient2, pageWidth / 2, 55, { align: "center" });

    // Subtitle
    doc.setFontSize(11);
    doc.setTextColor(200, 200, 200);
    doc.text("Your Personalized Website Quote", pageWidth / 2, 65, { align: "center" });

    // Client name
    if (userName) {
      doc.setFontSize(13);
      doc.setTextColor(26, 188, 156);
      doc.text(`Prepared for: ${userName}`, pageWidth / 2, 75, { align: "center" });
    }

    // Package box
    doc.setFillColor(30, 30, 30);
    doc.roundedRect(15, 85, pageWidth - 30, 35, 3, 3, 'F');
    doc.setDrawColor(26, 188, 156);
    doc.setLineWidth(0.5);
    doc.roundedRect(15, 85, pageWidth - 30, 35, 3, 3, 'S');
    
    doc.setFontSize(16);
    doc.setTextColor(26, 188, 156);
    doc.setFont("helvetica", "bold");
    doc.text(result.tier, pageWidth / 2, 95, { align: "center" });
    
    doc.setFontSize(12);
    doc.setTextColor(180, 180, 180);
    doc.setFont("helvetica", "normal");
    doc.text(`Timeline: ${result.timeline}`, pageWidth / 2, 105, { align: "center" });

    // BrandVelocity Price (highlighted)
    doc.setFillColor(26, 188, 156);
    doc.roundedRect(15, 128, pageWidth - 30, 28, 3, 3, 'F');
    
    doc.setFontSize(11);
    doc.setTextColor(0, 0, 0);
    doc.setFont("helvetica", "bold");
    doc.text("BrandVelocity Price", pageWidth / 2, 138, { align: "center" });
    
    doc.setFontSize(24);
    doc.setTextColor(0, 0, 0);
    doc.text(`£${result.exactPrice}`, pageWidth / 2, 150, { align: "center" });

    // Market comparison
    doc.setFillColor(40, 40, 40);
    doc.roundedRect(15, 163, pageWidth - 30, 22, 3, 3, 'F');
    
    doc.setFontSize(10);
    doc.setTextColor(150, 150, 150);
    doc.setFont("helvetica", "normal");
    doc.text("Market Average Price:", pageWidth / 2, 172, { align: "center" });
    
    doc.setFontSize(14);
    doc.setTextColor(200, 200, 200);
    doc.setFont("helvetica", "bold");
    doc.text(`£${result.marketPrice}`, pageWidth / 2, 181, { align: "center" });

    // Savings highlight
    doc.setFillColor(139, 92, 246); // Purple
    doc.roundedRect(15, 192, pageWidth - 30, 18, 3, 3, 'F');
    
    doc.setFontSize(13);
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.text(`You Save £${result.savings} (${result.savingsPercent}% less than market!)`, pageWidth / 2, 203, { align: "center" });

    // Features section
    doc.setFontSize(14);
    doc.setTextColor(26, 188, 156);
    doc.setFont("helvetica", "bold");
    doc.text("What's Included:", 20, 220);

    doc.setFontSize(9);
    doc.setTextColor(220, 220, 220);
    doc.setFont("helvetica", "normal");
    let yPos = 230;
    result.features.forEach((feature, index) => {
      doc.text(`✓ ${feature}`, 25, yPos);
      yPos += 6;
    });

    // Why choose us section
    yPos += 5;
    doc.setFontSize(12);
    doc.setTextColor(26, 188, 156);
    doc.setFont("helvetica", "bold");
    doc.text("Why BrandVelocity?", 20, yPos);
    
    yPos += 8;
    doc.setFontSize(9);
    doc.setTextColor(200, 200, 200);
    doc.setFont("helvetica", "normal");
    const benefits = [
      "💰 Transparent pricing - no hidden costs",
      "⚡ Fast turnaround times",
      "🎨 Premium quality at competitive rates",
      "🤝 Dedicated support throughout",
      "📈 SEO & performance optimized"
    ];
    
    benefits.forEach(benefit => {
      doc.text(benefit, 25, yPos);
      yPos += 6;
    });

    // Footer CTA
    doc.setFillColor(26, 188, 156);
    doc.roundedRect(15, 275, pageWidth - 30, 15, 3, 3, 'F');
    
    doc.setFontSize(11);
    doc.setTextColor(0, 0, 0);
    doc.setFont("helvetica", "bold");
    doc.text("Ready to get started? Contact us today!", pageWidth / 2, 285, { align: "center" });

    // Save PDF
    doc.save(`BrandVelocity-Quote-${userName || 'Client'}.pdf`);

    // Save to database
    // TODO: Re-enable when velocityQuote router is added
    toast.success("Quote downloaded successfully!");
  };

  const handleDownload = () => {
    if (!email || !userName) {
      setShowEmailForm(true);
      return;
    }
    generatePDF();
  };

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && userName) {
      setShowEmailForm(false);
      generatePDF();
    }
  };

  const progress = ((currentQuestion + 1) / questions.length) * 100;

  if (!isOpen) {
    return (
      <button
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
        onClick={(e) => {
          if (!isDragging) {
            setIsOpen(true);
          }
        }}
        className="fixed z-50 bg-gradient-to-r from-[#1abc9c] to-[#16a085] hover:from-[#16a085] hover:to-[#1abc9c] text-white shadow-2xl shadow-[#1abc9c]/60 px-4 py-4 md:px-6 md:py-6 text-xs md:text-sm font-semibold rounded-full group transition-all duration-300 cursor-move hover:scale-105"
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
        }}
        data-velocity-ai-trigger
      >
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 md:w-5 md:h-5" />
          <span>Velocity AI - Get Quote</span>
        </div>
      </button>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <Card className="w-full max-w-2xl bg-gradient-to-br from-gray-900 via-black to-gray-900 border-2 border-[#1abc9c]/30 shadow-2xl shadow-[#1abc9c]/20 max-h-[90vh] overflow-y-auto">
        <CardContent className="p-6 md:p-8">
          {/* Header */}
          <div className="flex justify-between items-start mb-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-10 h-10 bg-gradient-to-br from-[#1abc9c] to-[#16a085] rounded-xl flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">Velocity AI</h2>
                  <p className="text-sm text-gray-400">BrandVelocity Price Calculator</p>
                </div>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              className="text-gray-400 hover:text-white hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {!result ? (
            <>
              {/* Progress bar */}
              <div className="mb-6">
                <div className="flex justify-between text-sm text-gray-400 mb-2">
                  <span>Question {currentQuestion + 1} of {questions.length}</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-[#1abc9c] to-[#16a085] transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>

              {/* Question */}
              <div className="mb-6">
                <h3 className="text-xl font-bold text-white mb-4">
                  {questions[currentQuestion].question}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {questions[currentQuestion].options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => handleAnswer(option.value)}
                      className="p-4 bg-gradient-to-br from-gray-800 to-gray-900 hover:from-[#1abc9c]/20 hover:to-[#16a085]/20 border-2 border-gray-700 hover:border-[#1abc9c] rounded-xl text-left transition-all duration-300 group"
                    >
                      <span className="text-white font-medium group-hover:text-[#1abc9c] transition-colors">
                        {option.label}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Back button */}
              {currentQuestion > 0 && (
                <Button
                  onClick={handleBack}
                  variant="outline"
                  className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                >
                  ← Back
                </Button>
              )}
            </>
          ) : showEmailForm ? (
            <form onSubmit={handleEmailSubmit} className="space-y-4">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-white mb-2">Almost There!</h3>
                <p className="text-gray-400">Enter your details to download your personalized quote</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Your Name</label>
                <Input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="John Doe"
                  required
                  className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Email Address</label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                />
              </div>

              <div className="flex gap-3">
                <Button
                  type="button"
                  onClick={() => setShowEmailForm(false)}
                  variant="outline"
                  className="flex-1 border-gray-700 text-gray-300 hover:bg-gray-800"
                >
                  Back
                </Button>
                <Button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-[#1abc9c] to-[#16a085] hover:from-[#16a085] hover:to-[#1abc9c] text-white"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download PDF
                </Button>
              </div>
            </form>
          ) : (
            <div className="space-y-6">
              {/* Result header */}
              <div className="text-center">
                <div className="inline-flex items-center gap-2 bg-gradient-to-r from-[#1abc9c]/20 to-[#16a085]/20 border border-[#1abc9c]/50 rounded-full px-4 py-2 mb-4">
                  <Rocket className="w-5 h-5 text-[#1abc9c]" />
                  <span className="text-[#1abc9c] font-semibold">{result.tier}</span>
                </div>
                <h3 className="text-3xl font-bold text-white mb-2">Your Custom Quote</h3>
                <p className="text-gray-400">Timeline: {result.timeline}</p>
              </div>

              {/* Price comparison */}
              <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-6 border-2 border-gray-700">
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Market Price */}
                  <div className="text-center">
                    <p className="text-sm text-gray-400 mb-2">Market Average</p>
                    <div className="relative">
                      <p className="text-3xl font-bold text-gray-500 line-through">£{result.marketPrice}</p>
                      <div className="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                        Overpriced!
                      </div>
                    </div>
                  </div>

                  {/* BrandVelocity Price */}
                  <div className="text-center">
                    <p className="text-sm text-[#1abc9c] mb-2 font-semibold">BrandVelocity Price</p>
                    <p className="text-5xl font-bold text-white mb-2">£{result.exactPrice}</p>
                    <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-sm px-3 py-1 rounded-full">
                      <TrendingDown className="w-4 h-4" />
                      Save £{result.savings} ({result.savingsPercent}%)
                    </div>
                  </div>
                </div>
              </div>

              {/* Why we're cheaper callout */}
              <div className="bg-gradient-to-r from-[#1abc9c]/10 via-purple-500/10 to-pink-500/10 border-2 border-[#1abc9c]/30 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <Zap className="w-6 h-6 text-[#1abc9c] flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-bold text-white mb-2">Why Are We {result.savingsPercent}% Cheaper?</h4>
                    <p className="text-sm text-gray-300 leading-relaxed">
                      Most agencies charge <span className="text-[#1abc9c] font-semibold">£{result.marketPrice}+</span> for similar projects. 
                      At BrandVelocity, we've streamlined our process and cut unnecessary overhead to pass the savings directly to you. 
                      <span className="text-purple-400 font-semibold"> Same quality, better price.</span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Features */}
              <div>
                <h4 className="font-bold text-white mb-3 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[#1abc9c]" />
                  What's Included
                </h4>
                <div className="grid md:grid-cols-2 gap-2">
                  {result.features.map((feature, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm text-gray-300">
                      <span className="text-[#1abc9c] mt-0.5">✓</span>
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-3 pt-4">
                <Button
                  onClick={handleReset}
                  variant="outline"
                  className="flex-1 border-gray-700 text-gray-300 hover:bg-gray-800"
                >
                  Start Over
                </Button>
                <Button
                  onClick={handleDownload}
                  className="flex-1 bg-gradient-to-r from-[#1abc9c] to-[#16a085] hover:from-[#16a085] hover:to-[#1abc9c] text-white shadow-lg shadow-[#1abc9c]/30"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Quote PDF
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

