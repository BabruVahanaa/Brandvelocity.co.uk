import { useState, useEffect } from 'react';

interface LoadingTransitionProps {
  variant?: 'space-launch' | 'velocity-reveal' | 'cosmic-fade' | 'particle-burst' | 'warp-speed';
}

export default function LoadingTransition({ variant = 'space-launch' }: LoadingTransitionProps) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Check if user has already seen the transition in this session
    const hasSeenTransition = sessionStorage.getItem('brandvelocity-transition-seen');
    
    if (hasSeenTransition) {
      setIsVisible(false);
      return;
    }

    // Hide transition after animation completes
    const timer = setTimeout(() => {
      setIsVisible(false);
      sessionStorage.setItem('brandvelocity-transition-seen', 'true');
    }, 3500); // Adjust based on variant duration

    return () => clearTimeout(timer);
  }, []);

  if (!isVisible) return null;

  return (
    <>
      {variant === 'space-launch' && <SpaceLaunchTransition />}
      {variant === 'velocity-reveal' && <VelocityRevealTransition />}
      {variant === 'cosmic-fade' && <CosmicFadeTransition />}
      {variant === 'particle-burst' && <ParticleBurstTransition />}
      {variant === 'warp-speed' && <WarpSpeedTransition />}
    </>
  );
}

// Option 1: Space Launch - Rocket launch with brand reveal
function SpaceLaunchTransition() {
  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black space-launch-transition">
      <div className="relative">
        {/* Stars background */}
        <div className="absolute inset-0 stars-bg"></div>
        
        {/* Brand name */}
        <div className="relative z-10 text-center">
          <h1 className="text-6xl md:text-8xl font-bold mb-4 brand-reveal">
            <span className="text-white">Brand</span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500">
              Velocity
            </span>
          </h1>
          <div className="rocket-launch">
            <div className="rocket">🚀</div>
          </div>
          <p className="text-cyan-400 text-xl md:text-2xl mt-8 tagline-fade">
            Accelerating Brands Into The Future
          </p>
        </div>
      </div>

      <style>{`
        .space-launch-transition {
          animation: fadeOut 0.5s ease-in 3s forwards;
        }

        .stars-bg {
          background-image: 
            radial-gradient(2px 2px at 20% 30%, white, transparent),
            radial-gradient(2px 2px at 60% 70%, white, transparent),
            radial-gradient(1px 1px at 50% 50%, white, transparent),
            radial-gradient(1px 1px at 80% 10%, white, transparent),
            radial-gradient(2px 2px at 90% 60%, white, transparent),
            radial-gradient(1px 1px at 33% 80%, white, transparent),
            radial-gradient(1px 1px at 15% 90%, white, transparent);
          background-size: 200% 200%;
          animation: twinkle 3s ease-in-out infinite;
        }

        @keyframes twinkle {
          0%, 100% { opacity: 0.5; }
          50% { opacity: 1; }
        }

        .brand-reveal {
          opacity: 0;
          transform: scale(0.8);
          animation: brandReveal 1s ease-out 0.5s forwards;
        }

        @keyframes brandReveal {
          0% {
            opacity: 0;
            transform: scale(0.8) translateY(20px);
          }
          100% {
            opacity: 1;
            transform: scale(1) translateY(0);
          }
        }

        .rocket-launch {
          position: absolute;
          bottom: -100px;
          left: 50%;
          transform: translateX(-50%);
        }

        .rocket {
          font-size: 3rem;
          animation: rocketLaunch 2s ease-in 1s forwards;
          filter: drop-shadow(0 0 20px rgba(96, 165, 250, 0.8));
        }

        @keyframes rocketLaunch {
          0% {
            transform: translateY(0) rotate(0deg);
            opacity: 1;
          }
          100% {
            transform: translateY(-800px) rotate(-45deg);
            opacity: 0;
          }
        }

        .tagline-fade {
          opacity: 0;
          animation: fadeInUp 0.8s ease-out 1.5s forwards;
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes fadeOut {
          to {
            opacity: 0;
            visibility: hidden;
          }
        }
      `}</style>
    </div>
  );
}

// Option 2: Velocity Reveal - Speed lines with brand emergence
function VelocityRevealTransition() {
  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black velocity-reveal-transition overflow-hidden">
      {/* Speed lines */}
      <div className="absolute inset-0 speed-lines"></div>
      
      <div className="relative z-10 text-center">
        <div className="brand-split">
          <div className="brand-part brand-left">
            <span className="text-6xl md:text-9xl font-bold text-white">Brand</span>
          </div>
          <div className="brand-part brand-right">
            <span className="text-6xl md:text-9xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500">
              Velocity
            </span>
          </div>
        </div>
        <div className="velocity-bar"></div>
        <p className="text-cyan-400 text-xl md:text-2xl mt-8 subtitle-reveal">
          We Build Brands That Matter
        </p>
      </div>

      <style>{`
        .velocity-reveal-transition {
          animation: fadeOut 0.5s ease-in 3s forwards;
        }

        .speed-lines {
          background: repeating-linear-gradient(
            90deg,
            transparent,
            transparent 50px,
            rgba(96, 165, 250, 0.1) 50px,
            rgba(96, 165, 250, 0.1) 52px
          );
          animation: speedLines 1s linear infinite;
        }

        @keyframes speedLines {
          from { transform: translateX(0); }
          to { transform: translateX(52px); }
        }

        .brand-split {
          display: flex;
          gap: 1rem;
          justify-content: center;
          align-items: center;
        }

        .brand-part {
          opacity: 0;
        }

        .brand-left {
          animation: slideInLeft 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) 0.3s forwards;
        }

        .brand-right {
          animation: slideInRight 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) 0.5s forwards;
        }

        @keyframes slideInLeft {
          from {
            opacity: 0;
            transform: translateX(-100px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes slideInRight {
          from {
            opacity: 0;
            transform: translateX(100px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        .velocity-bar {
          height: 4px;
          width: 0;
          background: linear-gradient(90deg, #06b6d4, #a855f7, #ec4899);
          margin: 2rem auto;
          animation: velocityBar 1s ease-out 1.2s forwards;
          box-shadow: 0 0 20px rgba(168, 85, 247, 0.8);
        }

        @keyframes velocityBar {
          to { width: 300px; }
        }

        .subtitle-reveal {
          opacity: 0;
          animation: fadeInUp 0.8s ease-out 1.8s forwards;
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes fadeOut {
          to {
            opacity: 0;
            visibility: hidden;
          }
        }
      `}</style>
    </div>
  );
}

// Option 3: Cosmic Fade - Nebula background with elegant fade
function CosmicFadeTransition() {
  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center cosmic-fade-transition overflow-hidden">
      {/* Animated gradient background */}
      <div className="absolute inset-0 cosmic-bg"></div>
      
      {/* Particles */}
      <div className="absolute inset-0 particles">
        {[...Array(20)].map((_, i) => (
          <div key={i} className="particle" style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 2}s`,
            animationDuration: `${2 + Math.random() * 2}s`
          }}></div>
        ))}
      </div>

      <div className="relative z-10 text-center">
        <h1 className="text-7xl md:text-9xl font-bold mb-6 brand-glow">
          <span className="text-white brand-letter" style={{ animationDelay: '0s' }}>B</span>
          <span className="text-white brand-letter" style={{ animationDelay: '0.1s' }}>r</span>
          <span className="text-white brand-letter" style={{ animationDelay: '0.2s' }}>a</span>
          <span className="text-white brand-letter" style={{ animationDelay: '0.3s' }}>n</span>
          <span className="text-white brand-letter" style={{ animationDelay: '0.4s' }}>d</span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 brand-letter" style={{ animationDelay: '0.5s' }}>V</span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 brand-letter" style={{ animationDelay: '0.6s' }}>e</span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 brand-letter" style={{ animationDelay: '0.7s' }}>l</span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 brand-letter" style={{ animationDelay: '0.8s' }}>o</span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 brand-letter" style={{ animationDelay: '0.9s' }}>c</span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 brand-letter" style={{ animationDelay: '1s' }}>i</span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 brand-letter" style={{ animationDelay: '1.1s' }}>t</span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 brand-letter" style={{ animationDelay: '1.2s' }}>y</span>
        </h1>
        <div className="glow-ring"></div>
      </div>

      <style>{`
        .cosmic-fade-transition {
          animation: fadeOut 0.8s ease-in 2.8s forwards;
        }

        .cosmic-bg {
          background: radial-gradient(ellipse at center, 
            rgba(168, 85, 247, 0.3) 0%,
            rgba(59, 130, 246, 0.2) 30%,
            rgba(0, 0, 0, 1) 70%
          );
          animation: cosmicPulse 4s ease-in-out infinite;
        }

        @keyframes cosmicPulse {
          0%, 100% { transform: scale(1); opacity: 0.8; }
          50% { transform: scale(1.1); opacity: 1; }
        }

        .particle {
          position: absolute;
          width: 3px;
          height: 3px;
          background: white;
          border-radius: 50%;
          animation: particleFloat 3s ease-in-out infinite;
          box-shadow: 0 0 10px rgba(255, 255, 255, 0.8);
        }

        @keyframes particleFloat {
          0%, 100% { transform: translateY(0) scale(1); opacity: 0.3; }
          50% { transform: translateY(-30px) scale(1.5); opacity: 1; }
        }

        .brand-letter {
          display: inline-block;
          opacity: 0;
          animation: letterReveal 0.5s ease-out forwards;
          text-shadow: 0 0 30px rgba(168, 85, 247, 0.8);
        }

        @keyframes letterReveal {
          from {
            opacity: 0;
            transform: translateY(50px) rotateX(90deg);
          }
          to {
            opacity: 1;
            transform: translateY(0) rotateX(0);
          }
        }

        .glow-ring {
          width: 400px;
          height: 400px;
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          border: 2px solid rgba(168, 85, 247, 0.3);
          border-radius: 50%;
          animation: ringExpand 2s ease-out 0.5s forwards;
        }

        @keyframes ringExpand {
          from {
            width: 0;
            height: 0;
            opacity: 1;
          }
          to {
            width: 800px;
            height: 800px;
            opacity: 0;
          }
        }

        @keyframes fadeOut {
          to {
            opacity: 0;
            visibility: hidden;
          }
        }
      `}</style>
    </div>
  );
}

// Option 4: Particle Burst - Energetic particle explosion
function ParticleBurstTransition() {
  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black particle-burst-transition overflow-hidden">
      <div className="relative">
        {/* Center point */}
        <div className="burst-center"></div>
        
        {/* Burst particles */}
        <div className="burst-particles">
          {[...Array(30)].map((_, i) => (
            <div 
              key={i} 
              className="burst-particle"
              style={{
                '--angle': `${(360 / 30) * i}deg`,
                '--delay': `${i * 0.03}s`,
                '--distance': `${200 + Math.random() * 200}px`
              } as React.CSSProperties}
            ></div>
          ))}
        </div>

        {/* Brand text */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center brand-emerge">
            <h1 className="text-7xl md:text-9xl font-bold">
              <span className="text-white">Brand</span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500">
                Velocity
              </span>
            </h1>
            <div className="energy-wave"></div>
          </div>
        </div>
      </div>

      <style>{`
        .particle-burst-transition {
          animation: fadeOut 0.5s ease-in 3s forwards;
        }

        .burst-center {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          width: 20px;
          height: 20px;
          background: radial-gradient(circle, #a855f7, #ec4899);
          border-radius: 50%;
          animation: burstCenter 0.8s ease-out forwards;
          box-shadow: 0 0 50px rgba(168, 85, 247, 1);
        }

        @keyframes burstCenter {
          0% {
            width: 20px;
            height: 20px;
            opacity: 1;
          }
          50% {
            width: 100px;
            height: 100px;
            opacity: 1;
          }
          100% {
            width: 0;
            height: 0;
            opacity: 0;
          }
        }

        .burst-particles {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
        }

        .burst-particle {
          position: absolute;
          width: 4px;
          height: 4px;
          background: linear-gradient(45deg, #06b6d4, #a855f7);
          border-radius: 50%;
          animation: burstParticle 1.5s ease-out var(--delay) forwards;
          box-shadow: 0 0 10px rgba(168, 85, 247, 0.8);
        }

        @keyframes burstParticle {
          0% {
            transform: rotate(var(--angle)) translateX(0) scale(1);
            opacity: 1;
          }
          100% {
            transform: rotate(var(--angle)) translateX(var(--distance)) scale(0);
            opacity: 0;
          }
        }

        .brand-emerge {
          opacity: 0;
          transform: scale(0.5);
          animation: brandEmerge 1s ease-out 0.8s forwards;
        }

        @keyframes brandEmerge {
          from {
            opacity: 0;
            transform: scale(0.5) rotate(180deg);
          }
          to {
            opacity: 1;
            transform: scale(1) rotate(0deg);
          }
        }

        .energy-wave {
          height: 3px;
          width: 0;
          background: linear-gradient(90deg, transparent, #a855f7, #ec4899, transparent);
          margin: 2rem auto;
          animation: energyWave 1s ease-out 1.5s forwards;
          box-shadow: 0 0 20px rgba(168, 85, 247, 0.8);
        }

        @keyframes energyWave {
          to { width: 400px; }
        }

        @keyframes fadeOut {
          to {
            opacity: 0;
            visibility: hidden;
          }
        }
      `}</style>
    </div>
  );
}

// Option 5: Warp Speed - Star Wars-style hyperspace jump
function WarpSpeedTransition() {
  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black warp-speed-transition overflow-hidden">
      {/* Warp lines */}
      <div className="warp-container">
        {[...Array(50)].map((_, i) => (
          <div 
            key={i}
            className="warp-line"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              '--delay': `${Math.random() * 0.5}s`,
              '--duration': `${0.8 + Math.random() * 0.4}s`
            } as React.CSSProperties}
          ></div>
        ))}
      </div>

      {/* Brand text */}
      <div className="relative z-10 text-center warp-brand">
        <h1 className="text-7xl md:text-9xl font-bold mb-4">
          <span className="text-white warp-text">Brand</span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 warp-text" style={{ animationDelay: '0.2s' }}>
            Velocity
          </span>
        </h1>
        <p className="text-cyan-400 text-2xl warp-tagline">
          Entering Hyperspace...
        </p>
      </div>

      <style>{`
        .warp-speed-transition {
          animation: fadeOut 0.5s ease-in 3s forwards;
        }

        .warp-container {
          position: absolute;
          inset: 0;
          perspective: 500px;
        }

        .warp-line {
          position: absolute;
          width: 2px;
          height: 100px;
          background: linear-gradient(to bottom, transparent, #06b6d4, transparent);
          animation: warpLine var(--duration) linear var(--delay) infinite;
          transform-origin: center;
        }

        @keyframes warpLine {
          0% {
            transform: translateZ(0) scaleY(1);
            opacity: 0;
          }
          10% {
            opacity: 1;
          }
          100% {
            transform: translateZ(1000px) scaleY(3);
            opacity: 0;
          }
        }

        .warp-brand {
          animation: warpBrand 2s ease-out forwards;
        }

        @keyframes warpBrand {
          0% {
            transform: scale(3) translateZ(1000px);
            opacity: 0;
          }
          50% {
            opacity: 1;
          }
          100% {
            transform: scale(1) translateZ(0);
            opacity: 1;
          }
        }

        .warp-text {
          display: inline-block;
          opacity: 0;
          animation: warpTextReveal 0.8s ease-out forwards;
          text-shadow: 0 0 30px rgba(6, 182, 212, 0.8);
        }

        @keyframes warpTextReveal {
          from {
            opacity: 0;
            transform: scaleX(3) translateZ(500px);
            filter: blur(10px);
          }
          to {
            opacity: 1;
            transform: scaleX(1) translateZ(0);
            filter: blur(0);
          }
        }

        .warp-tagline {
          opacity: 0;
          animation: fadeInUp 0.8s ease-out 1.5s forwards;
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes fadeOut {
          to {
            opacity: 0;
            visibility: hidden;
          }
        }
      `}</style>
    </div>
  );
}

