import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import VelocityAI from "@/components/VelocityAI";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, Phone, MapPin, Clock, ArrowRight } from "lucide-react";

export default function Contact() {
  return (
    <div className="min-h-screen bg-black text-white">
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-[url('/nebula-hero.jpg')] bg-cover bg-center opacity-20"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-black via-purple-900/20 to-black"></div>
      </div>

      <Navigation />
      <VelocityAI />

      <div className="relative z-10 pt-32 pb-20">
        <div className="container mx-auto px-4">
          {/* Hero */}
          <div className="text-center mb-16 space-y-6">
            <h1 className="text-5xl md:text-7xl font-bold">
              Let's <span className="text-[#1abc9c]">Connect</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Ready to build something amazing? Get in touch and let's start the conversation.
            </p>
          </div>

          <div className="max-w-5xl mx-auto">
            {/* Main Contact Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
              {/* Email Card - Interactive */}
              <a 
                href="mailto:connect@brandvelocity.co.uk"
                className="group relative overflow-hidden bg-gradient-to-br from-[#1abc9c]/20 to-[#16a085]/10 border-2 border-[#1abc9c]/30 rounded-2xl p-8 hover:border-[#1abc9c] hover:shadow-2xl hover:shadow-[#1abc9c]/20 transition-all duration-300 transform hover:-translate-y-2"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#1abc9c]/10 rounded-full blur-3xl group-hover:bg-[#1abc9c]/30 transition-all duration-300"></div>
                
                <div className="relative">
                  <div className="flex items-start justify-between mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-[#1abc9c] to-[#16a085] rounded-2xl flex items-center justify-center group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 shadow-lg shadow-[#1abc9c]/50">
                      <Mail className="w-8 h-8 text-white" />
                    </div>
                    <ArrowRight className="w-6 h-6 text-[#1abc9c] opacity-0 group-hover:opacity-100 transform translate-x-2 group-hover:translate-x-0 transition-all duration-300" />
                  </div>
                  
                  <h3 className="text-2xl font-bold text-white mb-3">Email Us</h3>
                  <p className="text-[#1abc9c] font-semibold text-lg mb-2 group-hover:text-[#16a085] transition-colors">
                    connect@brandvelocity.co.uk
                  </p>
                  <p className="text-gray-400 text-sm">
                    Drop us a line anytime. We'll get back to you within 24 hours.
                  </p>
                </div>
              </a>

              {/* Phone Card - Interactive */}
              <a 
                href="tel:07426877552"
                className="group relative overflow-hidden bg-gradient-to-br from-purple-500/20 to-pink-500/10 border-2 border-purple-500/30 rounded-2xl p-8 hover:border-purple-500 hover:shadow-2xl hover:shadow-purple-500/20 transition-all duration-300 transform hover:-translate-y-2"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl group-hover:bg-purple-500/30 transition-all duration-300"></div>
                
                <div className="relative">
                  <div className="flex items-start justify-between mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 shadow-lg shadow-purple-500/50">
                      <Phone className="w-8 h-8 text-white" />
                    </div>
                    <ArrowRight className="w-6 h-6 text-purple-400 opacity-0 group-hover:opacity-100 transform translate-x-2 group-hover:translate-x-0 transition-all duration-300" />
                  </div>
                  
                  <h3 className="text-2xl font-bold text-white mb-3">Call Us</h3>
                  <p className="text-purple-400 font-semibold text-lg mb-2 group-hover:text-pink-400 transition-colors">
                    07426 877552
                  </p>
                  <p className="text-gray-400 text-sm">
                    Prefer to talk? Give us a call during business hours.
                  </p>
                </div>
              </a>
            </div>

            {/* Location & Hours Row */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Location */}
              <Card className="bg-gradient-to-br from-gray-900/80 to-black/80 border-gray-700/50 backdrop-blur-sm hover:border-[#1abc9c]/50 transition-all duration-300">
                <CardContent className="p-8">
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 bg-gradient-to-br from-[#1abc9c]/20 to-[#16a085]/20 rounded-xl flex items-center justify-center flex-shrink-0 border border-[#1abc9c]/30">
                      <MapPin className="w-7 h-7 text-[#1abc9c]" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white mb-2">Our Location</h3>
                      <p className="text-gray-300 text-lg">Plymouth, Devon, UK</p>
                      <p className="text-gray-500 text-sm mt-1">Serving Devon, Cornwall & Beyond</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Office Hours */}
              <Card className="bg-gradient-to-br from-gray-900/80 to-black/80 border-gray-700/50 backdrop-blur-sm hover:border-purple-500/50 transition-all duration-300">
                <CardContent className="p-8">
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-xl flex items-center justify-center flex-shrink-0 border border-purple-500/30">
                      <Clock className="w-7 h-7 text-purple-400" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-white mb-3">Office Hours</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Mon - Fri</span>
                          <span className="text-[#1abc9c] font-semibold">9:00 AM - 6:00 PM</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Saturday</span>
                          <span className="text-[#1abc9c] font-semibold">10:00 AM - 4:00 PM</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Sunday</span>
                          <span className="text-gray-600">Closed</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* CTA Banner */}
            <div className="mt-12 relative overflow-hidden bg-gradient-to-r from-[#1abc9c] via-purple-600 to-pink-600 rounded-3xl p-12 text-center">
              <div className="absolute inset-0 bg-[url('/galaxy-swirl.jpg')] bg-cover bg-center opacity-20"></div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
              
              <div className="relative z-10">
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                  Ready to Accelerate Your Brand?
                </h2>
                <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
                  Let's discuss how we can help you build a sustainable brand that stands out and drives lasting results.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <a 
                    href="mailto:connect@brandvelocity.co.uk"
                    className="inline-flex items-center justify-center gap-2 bg-white text-[#1abc9c] hover:bg-gray-100 font-bold px-8 py-4 rounded-xl transition-all duration-300 shadow-xl hover:shadow-2xl hover:scale-105"
                  >
                    <Mail className="w-5 h-5" />
                    Send Email
                  </a>
                  <a 
                    href="tel:07426877552"
                    className="inline-flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm text-white hover:bg-white/20 font-bold px-8 py-4 rounded-xl transition-all duration-300 border-2 border-white/40 hover:border-white hover:scale-105"
                  >
                    <Phone className="w-5 h-5" />
                    Call Now
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}

