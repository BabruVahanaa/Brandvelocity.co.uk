import { useState } from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import LoadingTransition from '@/components/LoadingTransition';

export default function TransitionDemo() {
  const [activeTransition, setActiveTransition] = useState<string | null>(null);

  const transitions = [
    {
      id: 'space-launch',
      name: 'Space Launch',
      description: 'Rocket launch with brand reveal and twinkling stars',
      duration: '3.5s',
      style: 'Energetic & Playful'
    },
    {
      id: 'velocity-reveal',
      name: 'Velocity Reveal',
      description: 'Speed lines with split brand emergence',
      duration: '3s',
      style: 'Dynamic & Modern'
    },
    {
      id: 'cosmic-fade',
      name: 'Cosmic Fade',
      description: 'Nebula background with letter-by-letter reveal',
      duration: '3.5s',
      style: 'Elegant & Sophisticated'
    },
    {
      id: 'particle-burst',
      name: 'Particle Burst',
      description: 'Energetic particle explosion with brand emergence',
      duration: '3.5s',
      style: 'Bold & Impactful'
    },
    {
      id: 'warp-speed',
      name: 'Warp Speed',
      description: 'Hyperspace jump with star trails',
      duration: '3.5s',
      style: 'Cinematic & Epic'
    }
  ];

  const handlePreview = (transitionId: string) => {
    // Clear session storage to allow transition to show again
    sessionStorage.removeItem('brandvelocity-transition-seen');
    setActiveTransition(transitionId);
    
    // Reset after animation completes
    setTimeout(() => {
      setActiveTransition(null);
    }, 4000);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <Navigation />
      
      {activeTransition && (
        <LoadingTransition variant={activeTransition as any} />
      )}

      <div className="container mx-auto px-4 py-20">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="text-white">Loading </span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500">
                Transitions
              </span>
            </h1>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Choose the perfect opening animation for your BrandVelocity website. 
              Click "Preview" to see each transition in action.
            </p>
          </div>

          {/* Transition Options */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {transitions.map((transition) => (
              <div
                key={transition.id}
                className="bg-gray-900 rounded-lg p-6 border border-gray-800 hover:border-purple-500 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/20"
              >
                <h3 className="text-2xl font-bold mb-3 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
                  {transition.name}
                </h3>
                <p className="text-gray-400 mb-4 min-h-[60px]">
                  {transition.description}
                </p>
                <div className="flex justify-between items-center mb-4 text-sm">
                  <span className="text-gray-500">Duration: {transition.duration}</span>
                  <span className="text-purple-400">{transition.style}</span>
                </div>
                <button
                  onClick={() => handlePreview(transition.id)}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105"
                >
                  Preview
                </button>
              </div>
            ))}
          </div>

          {/* Implementation Guide */}
          <div className="bg-gray-900 rounded-lg p-8 border border-gray-800 mb-12">
            <h2 className="text-3xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
              How to Implement
            </h2>
            
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold mb-3 text-white">Step 1: Choose Your Transition</h3>
                <p className="text-gray-400">
                  Preview each option above and select the one that best matches your brand personality.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 text-white">Step 2: Add to Your App</h3>
                <p className="text-gray-400 mb-3">
                  Import and add the LoadingTransition component to your main App.tsx file:
                </p>
                <pre className="bg-black p-4 rounded-lg overflow-x-auto">
                  <code className="text-cyan-400 text-sm">{`import LoadingTransition from '@/components/LoadingTransition';

function App() {
  return (
    <>
      <LoadingTransition variant="space-launch" />
      {/* Your other components */}
    </>
  );
}`}</code>
                </pre>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 text-white">Step 3: Choose Variant</h3>
                <p className="text-gray-400 mb-3">
                  Replace the variant prop with your chosen transition:
                </p>
                <ul className="list-disc list-inside text-gray-400 space-y-2 ml-4">
                  <li><code className="text-cyan-400">variant="space-launch"</code> - Rocket launch animation</li>
                  <li><code className="text-cyan-400">variant="velocity-reveal"</code> - Speed lines reveal</li>
                  <li><code className="text-cyan-400">variant="cosmic-fade"</code> - Nebula fade-in</li>
                  <li><code className="text-cyan-400">variant="particle-burst"</code> - Particle explosion</li>
                  <li><code className="text-cyan-400">variant="warp-speed"</code> - Hyperspace jump</li>
                </ul>
              </div>

              <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-4">
                <h4 className="font-semibold text-purple-400 mb-2">💡 Pro Tip</h4>
                <p className="text-gray-300 text-sm">
                  The transition only shows once per session (using sessionStorage). 
                  Users won't see it on every page navigation, only on their first visit.
                </p>
              </div>
            </div>
          </div>

          {/* Recommendations */}
          <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-lg p-8 border border-purple-500/30">
            <h2 className="text-3xl font-bold mb-6 text-white">Our Recommendations</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-xl font-semibold mb-3 text-cyan-400">🚀 Best for Energy</h3>
                <p className="text-gray-300 mb-2"><strong>Space Launch</strong> or <strong>Particle Burst</strong></p>
                <p className="text-gray-400 text-sm">
                  Perfect if you want to convey energy, innovation, and forward momentum.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 text-purple-400">✨ Best for Elegance</h3>
                <p className="text-gray-300 mb-2"><strong>Cosmic Fade</strong></p>
                <p className="text-gray-400 text-sm">
                  Ideal for a more sophisticated, premium brand presentation.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 text-pink-400">⚡ Best for Speed</h3>
                <p className="text-gray-300 mb-2"><strong>Velocity Reveal</strong> or <strong>Warp Speed</strong></p>
                <p className="text-gray-400 text-sm">
                  Emphasizes the "Velocity" in BrandVelocity with dynamic motion.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 text-cyan-400">🎬 Best Overall</h3>
                <p className="text-gray-300 mb-2"><strong>Warp Speed</strong></p>
                <p className="text-gray-400 text-sm">
                  Cinematic, memorable, and perfectly aligned with your space theme.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}

